// Minimal data used on charts.  These figures correspond to the
// Constellation Energy webinar example, but you can replace them
// with your own values or pull data from another source.

export const weatherHDD = {
  name: "Heating Degree Days",
  labels: ["October", "November"],
  values: [245, 510]
};

export const tradeLNG = {
  name: "Additional LNG Imports (Bcf/d)",
  labels: ["S. Korea", "Japan", "India", "Mexico", "E.U."],
  values: [0.4, 0.54, 0.8, 2.5, 1.35]
};

export const gasProduction = {
  name: "Dry Gas Production (Bcf/d)",
  labels: ["2022", "2023", "2024", "Aug ’25", "YTD ’25", "EIA ’25 Fcst", "EIA ’26 Fcst"],
  values: [98, 101, 103, 108, 106, 107, 106]
};

export const gasStorage = {
  name: "Underground Gas Storage (Bcf)",
  labels: ["Year Ago", "Current", "5-Yr Avg", "Oct ’25", "Mar ’26"],
  values: [3200, 3272, 3140, 3912, 1852]
};

export const priceYears  = ["2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029"];
export const priceIndex  = [18, 26, 36, 26, 28, 50, 0, 0, 0, 0];  // illustrative spot index
export const priceForward = [0, 0, 0, 0, 0, 45, 48, 47, 46, 46];  // illustrative forward curve