// Design tokens for the green 3D aesthetic used throughout the deck.
//
// The colours and sizing defined here are inspired by the Constellation Energy
// webinar theme: dark greens for headings, mid and light greens for accents
// and backgrounds, and neutral greys for body text. Cards have rounded
// corners and soft shadows to convey depth without overwhelming the
// content.

export const SIZE = { W: 10, H: 5.625 }; // 16:9 aspect ratio
export const GRID = { M: 0.5 };          // margin used for layout

export const COLORS = {
  bg:       "FFFFFF", // slide background
  green900: "0F3A2E",
  green700: "1E6F5C",
  green500: "3BA55D",
  green300: "7ACB8E",
  green100: "DDF2E3",
  gray900:  "111827",
  gray700:  "374151",
  gray400:  "9CA3AF",
  gray200:  "E5E7EB",
  white:    "FFFFFF"
};

// Card style: rounded rectangle with subtle shadow to create depth.
export const cardStyle = (pptx) => ({
  fill: { type: "solid", color: COLORS.white },
  line: { color: "FFFFFF", width: 0.25 },
  shadow: { type: "outer", angle: 45, blur: 12, offset: 3, color: "00000066", opacity: 0.5 },
  rectRadius: 18
});

// Section header styling.
export const chip = {
  fontFace: "Inter",
  fontSize: 12,
  color: COLORS.white,
  bold: true
};

// Typography definitions for various heading levels and paragraphs.
export const FONTS = {
  h1: { fontFace: "Inter", fontSize: 44, color: COLORS.green900, bold: true },
  h2: { fontFace: "Inter", fontSize: 28, color: COLORS.green900, bold: true },
  h3: { fontFace: "Inter", fontSize: 20, color: COLORS.gray900, bold: true },
  p:  { fontFace: "Inter", fontSize: 14, color: COLORS.gray900 },
  pMuted: { fontFace: "Inter", fontSize: 12, color: COLORS.gray700 }
};

// Reusable helper for drawing a title bar at the top of slides.
export function titleBar(slide, text, pptx) {
  // Draws a coloured bar across the top of the slide.  `pptx` is required
  // because the shape types live on the PptxGenJS instance, not on the
  // slide.  Without passing pptx, slide.pptx would be undefined.
  slide.addShape(pptx.ShapeType.rect, {
    x: 0,
    y: 0,
    w: SIZE.W,
    h: 0.9,
    fill: { type: "solid", color: COLORS.green900 }
  });
  slide.addText([{ text, options: { ...chip } }], { x: GRID.M, y: 0.22, w: 6, h: 0.5 });
}

// Helper to draw a green gradient panel.  This is useful for panels
// containing charts or callouts that benefit from a subtle background.
export function greenGradientPanel(slide, { x, y, w, h }, pptx) {
  // Draw a rounded rectangle with a gradient fill.  `pptx` is required
  // because shape types belong to the PptxGenJS instance, not to the slide.
  slide.addShape(pptx.ShapeType.roundRect, {
    x,
    y,
    w,
    h,
    rectRadius: 28,
    fill: {
      type: "gradient",
      color: COLORS.green500,
      color2: COLORS.green300,
      angle: 315
    },
    shadow: { type: "outer", angle: 45, blur: 14, offset: 3, color: "00000055", opacity: 0.6 },
    line: { color: "FFFFFF", width: 0 }
  });
}

// Chart base styling used by multiple charts in the deck.
export const chartBase = {
  barDir: "col",
  catAxisLabelColor: COLORS.gray700,
  valAxisLabelColor: COLORS.gray700,
  catAxisTitleColor: COLORS.gray700,
  valAxisTitleColor: COLORS.gray700,
  valAxisMinVal: 0,
  dataLabelColor: COLORS.gray700,
  titleColor: COLORS.green900,
  shadow: { type: "outer", angle: 45, blur: 10, offset: 2, color: "00000055", opacity: 0.6 }
};

// Default palette for charts.  Adjust or extend as needed for new series.
export const chartColors = [COLORS.green500, COLORS.green300, COLORS.green700, COLORS.gray400];