/*
 * Build script for the Constellation green 3‑D deck.
 *
 * This file constructs a 10×5.625 inch (16:9) PowerPoint using PptxGenJS.
 * Slide structure loosely follows a typical webinar recap with sections on
 * weather, trade negotiations, gas fundamentals, price trends and risks.
 * Charts and cards draw styling from the theme definitions in theme.js.
 */

import PptxGenJS from "pptxgenjs";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

// Import theme and data constants.
import {
  SIZE,
  GRID,
  COLORS,
  FONTS,
  chartBase,
  chartColors,
  titleBar,
  greenGradientPanel,
  cardStyle
} from "./theme.js";

import {
  weatherHDD,
  tradeLNG,
  gasProduction,
  gasStorage,
  priceYears,
  priceIndex,
  priceForward
} from "./data.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

const pptx = new PptxGenJS();
pptx.layout = "LAYOUT_16x9";

// Helper: adds a small muted footer note at bottom right of a slide.
function addFooter(slide, note = "") {
  slide.addText([
    { text: note, options: { ...FONTS.pMuted } }
  ], {
    x: SIZE.W - 3.5,
    y: SIZE.H - 0.4,
    w: 3.2,
    h: 0.3,
    align: "right"
  });
}

// Helper: adds a list of bullet points with consistent spacing.
function addBullets(slide, bullets, box) {
  slide.addText(
    bullets.map(t => ({ text: t, options: { ...FONTS.p, bullet: { indent: 12 } } })),
    { ...box, paraSpaceAfter: 6 }
  );
}

// Slide 1: Title
{
  const slide = pptx.addSlide();
  // Left half: white background for text
  slide.addShape(pptx.ShapeType.rect, {
    x: 0,
    y: 0,
    w: SIZE.W / 2,
    h: SIZE.H,
    fill: { color: COLORS.white }
  });
  // Right half: gradient or image; prefer image if available
  const bgPath = path.join(__dirname, "../assets/green-bg.jpg");
  if (fs.existsSync(bgPath)) {
    slide.addImage({ path: bgPath, x: SIZE.W / 2, y: 0, w: SIZE.W / 2, h: SIZE.H });
  } else {
    greenGradientPanel(slide, { x: SIZE.W / 2 + 0.2, y: 0.2, w: SIZE.W / 2 - 0.4, h: SIZE.H - 0.4 }, pptx);
  }
  // Title and subtitle
  slide.addText(
    [
      { text: "Constellation Webinar", options: { ...FONTS.pMuted, color: COLORS.green700 } }
    ],
    { x: GRID.M, y: 0.8, w: 4.8, h: 0.4 }
  );
  slide.addText(
    [
      { text: "Trade Talks &", options: { ...FONTS.h1 } },
      { text: "\nMarket Intelligence", options: { ...FONTS.h1 } }
    ],
    { x: GRID.M, y: 1.2, w: 4.8, h: 2.4 }
  );
  slide.addText(
    [
      { text: "September 10 2025", options: { ...FONTS.p, color: COLORS.green700 } }
    ],
    { x: GRID.M, y: 3.8, w: 3.5, h: 0.4 }
  );
  addFooter(slide, "Source details in appendix.");
}

// Slide 2: Agenda
{
  const slide = pptx.addSlide();
  titleBar(slide, "Agenda", pptx);
  // Card for bullets
  slide.addShape(pptx.ShapeType.roundRect, {
    x: GRID.M,
    y: 1.2,
    w: 5.5,
    h: 3.3,
    ...cardStyle(pptx)
  });
  addBullets(slide, [
    "Weather & ENSO Outlook",
    "Trade Negotiations & Energy Exports",
    "Gas Production & Storage",
    "Offshore Wind & Auctions",
    "Market Trends & Outlook",
    "Risks & Conclusions"
  ], { x: GRID.M + 0.4, y: 1.45, w: 4.7, h: 3.0 });
  addFooter(slide);
}

// Slide 3: Weather & ENSO Outlook
{
  const slide = pptx.addSlide();
  titleBar(slide, "Weather & ENSO Outlook", pptx);
  // Card for text
  slide.addShape(pptx.ShapeType.roundRect, {
    x: GRID.M,
    y: 1.1,
    w: 5.5,
    h: 3.6,
    ...cardStyle(pptx)
  });
  addBullets(slide, [
    "Summer 2025 ranked ninth warmest; near‑normal conditions likely Plains & Southeast; warmer North & interior West.",
    "Nov outlook: mild East; cold air develops in western Canada; brief cold shot still possible in East.",
    "ENSO: neutral → weak La Niña; high variability this winter."
  ], { x: GRID.M + 0.4, y: 1.35, w: 4.7, h: 3.0 });
  // Chart: Heating Degree Days
  slide.addChart(pptx.ChartType.bar, [
    { name: weatherHDD.name, labels: weatherHDD.labels, values: weatherHDD.values }
  ], {
    x: 6.1,
    y: 1.3,
    w: 3.3,
    h: 2.7,
    ...chartBase,
    chartColors
  });
  slide.addText([
    { text: "Heating Degree Day Forecast", options: { ...FONTS.h3, color: COLORS.green900 } }
  ], { x: 6.1, y: 1.0, w: 3.3, h: 0.3 });
  addFooter(slide, "NOAA & internal forecasts.");
}

// Slide 4: Trade Negotiations & Energy Exports
{
  const slide = pptx.addSlide();
  titleBar(slide, "Trade Negotiations & Energy Exports", pptx);
  slide.addShape(pptx.ShapeType.roundRect, {
    x: GRID.M,
    y: 1.1,
    w: 5.5,
    h: 3.6,
    ...cardStyle(pptx)
  });
  addBullets(slide, [
    "Recent deals imply ~5.5 Bcf/d of added LNG demand (S. Korea, Japan, India, Mexico, E.U.).",
    "Tariff relief + licensing reforms accelerate LNG infrastructure build‑out.",
    "Open question: can U.S. supply scale quickly enough to meet multi‑year commitments?"
  ], { x: GRID.M + 0.4, y: 1.35, w: 4.7, h: 3.0 });
  slide.addChart(pptx.ChartType.bar, [
    { name: tradeLNG.name, labels: tradeLNG.labels, values: tradeLNG.values }
  ], {
    x: 6.1,
    y: 1.3,
    w: 3.3,
    h: 2.7,
    ...chartBase,
    chartColors,
    title: "LNG Imports via Trade Deals",
    showTitle: true
  });
  addFooter(slide, "Selected country commitments.");
}

// Slide 5: Gas Production & Storage
{
  const slide = pptx.addSlide();
  titleBar(slide, "Gas Production & Storage", pptx);
  // Production chart
  slide.addChart(pptx.ChartType.bar, [
    { name: gasProduction.name, labels: gasProduction.labels, values: gasProduction.values }
  ], {
    x: GRID.M,
    y: 1.3,
    w: 4.6,
    h: 2.5,
    ...chartBase,
    chartColors,
    title: "U.S. Dry Gas Production",
    showTitle: true
  });
  // Storage chart
  slide.addChart(pptx.ChartType.bar, [
    { name: gasStorage.name, labels: gasStorage.labels, values: gasStorage.values }
  ], {
    x: 5.4,
    y: 1.3,
    w: 4.6,
    h: 2.5,
    ...chartBase,
    chartColors,
    title: "Underground Gas Storage & Forecast",
    showTitle: true
  });
  // Summary bullets below charts
  slide.addShape(pptx.ShapeType.roundRect, {
    x: GRID.M,
    y: 3.95,
    w: 9,
    h: 0.9,
    ...cardStyle(pptx)
  });
  addBullets(slide, [
    "Aug output ~107 Bcf/d; YTD ~105 Bcf/d keeps supply robust.",
    "Storage ~3.27 Tcf now; EIA sees ~3.91 Tcf end‑Oct → ~1.85 Tcf by Mar.",
    "Producers may throttle if storage fills early."
  ], { x: GRID.M + 0.3, y: 4.05, w: 8.3, h: 0.7 });
  addFooter(slide, "EIA, industry trackers.");
}

// Slide 6: Market Price Trends
{
  const slide = pptx.addSlide();
  titleBar(slide, "Market Price Trends", pptx);
  // Text panel
  slide.addShape(pptx.ShapeType.roundRect, {
    x: GRID.M,
    y: 1.1,
    w: 5.5,
    h: 3.6,
    ...cardStyle(pptx)
  });
  addBullets(slide, [
    "NYMEX gas >$3/MMBtu despite tariff risk; recent rallies track oil & LNG headlines.",
    "West Hub index spike in 2022; forward curve now flattish/stable in high‑40s.",
    "Regional hubs show similar pattern: elevated spot, steadier forwards."
  ], { x: GRID.M + 0.4, y: 1.35, w: 4.7, h: 3.0 });
  // Line chart: price index vs forward
  slide.addChart(pptx.ChartType.line, [
    { name: "Index", labels: priceYears, values: priceIndex },
    { name: "Forward", labels: priceYears, values: priceForward }
  ], {
    x: 6.1,
    y: 1.3,
    w: 3.3,
    h: 2.7,
    catAxisTitle: "Year",
    valAxisTitle: "$ / MWh",
    showCatAxisTitle: true,
    showValAxisTitle: true,
    title: "West Hub: Index vs Forward",
    showTitle: true,
    chartColors: [COLORS.green700, COLORS.green300],
    marker: true,
    ...chartBase
  });
  addFooter(slide, "Index vs forwards (illustrative).");
}

// Slide 7: Risks & Conclusions
{
  const slide = pptx.addSlide();
  titleBar(slide, "Risks & Conclusions", pptx);
  slide.addShape(pptx.ShapeType.roundRect, {
    x: GRID.M,
    y: 1.1,
    w: 9,
    h: 3.6,
    ...cardStyle(pptx)
  });
  addBullets(slide, [
    "Infrastructure & permitting cadence may lag demand growth → volatility risk.",
    "Offshore wind uncertainty shifts attention to pipeline & thermal reliability.",
    "Geopolitics (Russia–China pipes, tariff dynamics) add export‑mix uncertainty.",
    "Diversified supply portfolios + winter weather vigilance recommended."
  ], { x: GRID.M + 0.4, y: 1.35, w: 8.2, h: 3.0 });
  addFooter(slide, "Synthesis of webinar themes.");
}

// Write file
await pptx.writeFile({ fileName: "deck.pptx" });
console.log("✓ Built deck.pptx");