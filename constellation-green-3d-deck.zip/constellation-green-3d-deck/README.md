# Constellation Webinar Deck — Green 3D Aesthetic

This project provides a clean, modern, green‑themed PowerPoint deck built with **PptxGenJS**.  It uses rounded cards with soft shadows, gradient panels and a coherent colour palette to evoke a subtle three‑dimensional effect.

## Quick start

Install dependencies and build the PowerPoint:

```bash
npm install
npm run build
```

The build script writes the file `deck.pptx` to the project root.

To export the deck as a PDF (optional), you need LibreOffice installed.  Run:

```bash
npm run pdf
```

This will convert the generated PowerPoint into `deck.pdf` in the project root.

## Assets

Place an abstract green image at `assets/green-bg.jpg`.  A default green swirl background is included in this repository.

## Customising content

* Edit `src/data.js` to plug in real figures from your analysis.
* Tweak colours, shadows and chart palettes inside `src/theme.js`.
* Add or modify slides in `src/build.js` to tailor the narrative.

## Notes on sources

Figures and slide topics reflect the uploaded **Constellation Energy Market Intelligence Webinar** report (10 September 2025).  See citations in the comments of the slides for more details.